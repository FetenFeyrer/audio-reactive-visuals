import Message from "./Message";
import ListGroup from "./components/ListGroup.tsx";

function App() {
  return (
    <>
      <div>
        <Message />
      </div>

      <div>
        <ListGroup />
      </div>
    </>
  );
}

export default App;
